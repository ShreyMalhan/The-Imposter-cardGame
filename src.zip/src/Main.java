//-----------------------------------------
// NAME		: Shrey Malhan
// STUDENT NUMBER	: 7824571
// COURSE		: COMP 2150
// INSTRUCTOR	: Mike
// ASSIGNMENT	: assignment 3
// QUESTION	: question 1
//
// REMARKS: In this assignment you will be implementing "whodunit?", a game that
// involves deduction to determine the “who, where and how” of a murder.
//
//
//-----------------------------------------

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        ArrayList<Card> ppl = new ArrayList<>();
        ArrayList<Card> place = new ArrayList<>();
        ArrayList<Card> weapon = new ArrayList<>();
        ArrayList<IPlayer> playerList = new ArrayList<>();


        Scanner input = new Scanner(System.in);
        int num = 0;
        boolean done = false;


        // Number of computer playes
        do{
            try {
                System.out.println("How many computer opponents would you like to play against?");
                num = input.nextInt();
                if(num > 0){
                    done = true;
                }else {
                    System.out.println("Number should be greater than 0");
                }
            }catch (InputMismatchException e){
                System.out.println("That is not a valid input. Try again!");
                input.next();
            }

        }while (!done);

        //creates desired number of computer player
        for (int i = 0; i < num; i++) {
            playerList.add(new ComputerPlayer());
        }

        playerList.add(new HumanPlayer()); // to add the Human player to the list

        // Creates Cards for the game
        ppl.add(new Card("Suspect", "Prof. Domaratzki"));
        ppl.add(new Card("Suspect", "Prof. Li"));
        ppl.add(new Card("Suspect", "Prof. Boyer"));
        ppl.add(new Card("Suspect", "Prof. Miller"));
        ppl.add(new Card("Suspect", "Prof. Wang"));

        place.add(new Card("Location", "Comp 2150"));
        place.add(new Card("Location", "Comp 2160"));
        place.add(new Card("Location", "Comp 2140"));
        place.add(new Card("Location", "Comp 2280"));
        place.add(new Card("Location", "Comp 2080"));

        weapon.add(new Card("Weapon", "Mid Term"));
        weapon.add(new Card("Weapon", "Final Exam"));
        weapon.add(new Card("Weapon", "Lab"));
        weapon.add(new Card("Weapon", "Assignments"));
        weapon.add(new Card("Weapon", "Group Work"));

        Model model = new Model(num, ppl, place, weapon, playerList);

        // Runs the game
        model.run();

    }

}
